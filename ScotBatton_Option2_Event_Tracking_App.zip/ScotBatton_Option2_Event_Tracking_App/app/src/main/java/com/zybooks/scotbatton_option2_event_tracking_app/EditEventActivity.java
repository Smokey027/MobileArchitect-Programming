package com.zybooks.scotbatton_option2_event_tracking_app;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.zybooks.scotbatton_option2_event_tracking_app.R;

import androidx.appcompat.app.AppCompatActivity;

public class EditEventActivity extends AppCompatActivity {

    private EditText titleEditText;
    private EditText dateEditText;
    private EditText locationEditText;
    private Button saveEventButton;
    private DataBase dbHelper;
    private int eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        dbHelper = new DataBase(this);

        titleEditText = findViewById(R.id.titleEditText);
        dateEditText = findViewById(R.id.dateEditText);
        locationEditText = findViewById(R.id.locationEditText);
        saveEventButton = findViewById(R.id.saveEventButton);

        Intent intent = getIntent();
        eventId = intent.getIntExtra("event_id", -1);

        Event event = getEventDetails(eventId);

        titleEditText.setText(event.getTitle());
        dateEditText.setText(event.getDate());
        locationEditText.setText(event.getLocation());

        saveEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleEditText.getText().toString().trim();
                String date = dateEditText.getText().toString().trim();
                String location = locationEditText.getText().toString().trim();

                if (!title.isEmpty() && !date.isEmpty() && !location.isEmpty()) {
                    dbHelper.updateEvent(eventId, title, date, location);
                    Toast.makeText(EditEventActivity.this, "Event updated", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(EditEventActivity.this, EventListActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(EditEventActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private Event getEventDetails(int eventId) {
        Cursor cursor = dbHelper.getAllEvents();
        if (((Cursor) cursor).moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("event_id"));
                if (id == eventId) {
                    String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                    String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                    String location = cursor.getString(cursor.getColumnIndexOrThrow("location"));
                    cursor.close();
                    return new Event(eventId, title, date, location);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return null;
    }
}

