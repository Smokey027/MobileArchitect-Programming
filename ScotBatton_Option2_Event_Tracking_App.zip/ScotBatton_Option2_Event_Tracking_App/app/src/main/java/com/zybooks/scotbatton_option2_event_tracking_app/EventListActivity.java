package com.zybooks.scotbatton_option2_event_tracking_app;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.zybooks.scotbatton_option2_event_tracking_app.R;

public class EventListActivity extends AppCompatActivity {

    private DataBase dbHelper;
    private SimpleCursorAdapter dataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        dbHelper = new DataBase(this);

        // Open the database connection
        dbHelper.getWritableDatabase(); // Ensure the database is created and open

        displayListView();
    }

    private void displayListView() {
        Cursor cursor = dbHelper.getAllEvents();

        String[] columns = new String[] {
                DataBase.KEY_EVENT_TITLE,
                DataBase.KEY_EVENT_DATE,
                DataBase.KEY_EVENT_LOCATION
        };

        int[] to = new int[] {
                R.id.titleTextView,
                R.id.dateTextView,
                R.id.locationTextView
        };

        dataAdapter = new SimpleCursorAdapter(
                this, R.layout.event_info,
                cursor,
                columns,
                to,
                0);

        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(dataAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View view,
                                    int position, long id) {
                Cursor cursor = (Cursor) listView.getItemAtPosition(position);
                String eventName = cursor.getString(cursor.getColumnIndexOrThrow(DataBase.KEY_EVENT_TITLE));
                Toast.makeText(getApplicationContext(), eventName, Toast.LENGTH_SHORT).show();
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final long deleteId = id;
                new AlertDialog.Builder(EventListActivity.this)
                        .setTitle("Delete Event")
                        .setMessage("Are you sure you want to delete this event?")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dbHelper.deleteEvent((int) deleteId); // Cast deleteId to int for proper deletion
                                displayListView(); // Refresh the list after deletion
                            }
                        })
                        .setNegativeButton(android.R.string.no, null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Open the database connection again if activity is resumed
        dbHelper.getWritableDatabase();
        displayListView();
    }

    @Override
    protected void onPause() {
        // Close the database connection when activity is paused
        dbHelper.close();
        super.onPause();
    }
}

